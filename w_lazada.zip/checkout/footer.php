        </section>

        <footer>
            <div class="container">
                <section class="co_footer text-center">
                    <p>Bạn cần hỗ trợ? Gọi Hotline 08 3942 1188 hoặc 04 7300 1188</p>
                    <p>&copy; Copyright 2013 - 2014, lz.vn</p>
                </section>
            </div>
        </footer>

        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/checkout.js"></script>
    </body>
</html>

