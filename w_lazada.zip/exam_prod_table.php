<table class="table table-bordered table-striped">
    <tbody><tr>
            <td class="specification-table__property">SKU</td>
            <td id="pdtsku" class="specification-table__value">SA937ELAA1P3TFVNAMZ-2826188</td>
        </tr>
        <tr>
            <td class="bold">Camera Back</td>
            <td>11-15MP</td>
        </tr>
        <tr>
            <td class="bold">Camera trước</td>
            <td>7 MP trở lên</td>
        </tr>
        <tr>
            <td class="bold">Điều kiện</td>
            <td>Mới</td>
        </tr>
        <tr>
            <td class="bold">Screen Size (inches)</td>
            <td>5.5</td>
        </tr>
        <tr>
            <td class="bold">Mẫu mã</td>
            <td>Lan Anh Mobile (Hà Nội)-Galaxy J7 Prime - Black</td>
        </tr>
        <tr>
            <td class="bold">Hệ điều hành</td>
            <td>Android 6.0 Marshmallow</td>
        </tr>
        <tr>
            <td class="bold">Phone Features</td>
            <td>Touchscreen</td>
        </tr>
        <tr>
            <td class="bold">Processor Type</td>
            <td>Octa-core</td>
        </tr>
        <tr>
            <td class="bold">Kích thước sản phẩm (D x R x C cm)</td>
            <td>151.5 x 74.9 x 8.1 mm.</td>
        </tr>
        <tr>
            <td class="bold">Trọng lượng (KG)</td>
            <td>0.1</td>
        </tr>
        <tr>
            <td class="bold">Sản xuất tại</td>
            <td>Trung Quốc</td>
        </tr>
        <tr>
            <td class="bold">RAM memory</td>
            <td>3GB</td>
        </tr>
        <tr>
            <td class="bold">Screen Type</td>
            <td>TFT LCD</td>
        </tr>
        <tr>
            <td class="bold">Sim Slots</td>
            <td>2</td>
        </tr>
        <tr>
            <td class="bold">Bộ nhớ trong</td>
            <td>32GB</td>
        </tr>
        <tr>
            <td class="bold">Video Resolution</td>
            <td>1080p</td>
        </tr>
        <tr>
            <td class="bold">Thời gian bảo hành</td>
            <td>12 tháng</td>
        </tr>
        <tr>
            <td class="bold">Loại hình bảo hành</td>
            <td>Bảo hành điện tử</td>
        </tr>
    </tbody></table>

